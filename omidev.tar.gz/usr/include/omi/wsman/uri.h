/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#ifndef _omi_wsman_uri_h
#define _omi_wsman_uri_h

#define URI_CIMBINDING ZT("http://schemas.dmtf.org/wbem/wsman/1/cimbinding")

#endif /* _omi_wsman_uri_h */
