/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#ifndef _mof_config_h
#define _mof_config_h

#include <common/common.h>

#endif /* _mof_config_h */
