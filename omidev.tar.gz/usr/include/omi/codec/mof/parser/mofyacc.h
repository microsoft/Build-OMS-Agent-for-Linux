/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#ifndef _mof_yacc_h
#define _mof_yacc_h

#include "mofy.tab.h"

#endif /* _mof_yacc_h */
